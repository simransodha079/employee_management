<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h1>Edit Profile</h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(Auth::user()->name); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
            </div>

            <div class="form-group">
                <label for="contact">Contact Number</label>
                <input type="tel" class="form-control" id="contact" name="contact" value="<?php echo e(Auth::user()->contact); ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea class="form-control" id="address" name="address" required><?php echo e(Auth::user()->address); ?></textarea>
            </div>

            <div class="form-group">
                <label for="profile_image">Profile Image</label>
                <input type="file" class="form-control-file" id="profile_image" name="profile_image">
                <?php if(Auth::user()->profile_image): ?>
                    <img src="<?php echo e(Auth::user()->profile_image); ?>" alt="Profile Image" class="img-thumbnail mt-2">
                    <a href="<?php echo e(route('profile.delete-image')); ?>" class="card-link">Remove Image</a>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="designation">Designation</label>
                <input type="text" class="form-control" id="designation" name="designation" value="<?php echo e(Auth::user()->designation); ?>" required>
            </div>

            <div class="form-group">
                <label for="join_date">Join Date</label>
                <input type="date" class="form-control" id="join_date" name="join_date" value="<?php echo e(Auth::user()->join_date); ?>" required>
            </div>

            <div class="form-group">
                <label for="date_of_birth">Date of Birth</label>
                <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?php echo e(Auth::user()->date_of_birth); ?>" required>
            </div>

            <div class="form-group">
                <label for="experience">Years of Experience</label>
                <input type="number" class="form-control" id="experience" name="experience" value="<?php echo e(Auth::user()->experience); ?>" min="0" required>
            </div>

            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>

        <p class="mt-3">
            <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Logout</a>
        </p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\employee_management\resources\views/profile/edit.blade.php ENDPATH**/ ?>