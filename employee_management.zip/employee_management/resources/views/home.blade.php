@extends('layouts.user')
@section('title','home')
@section('contents')
home
@endsection