<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register()
    {
        return view('auth/register');
    }

    public function registerSave(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'contact' => 'required|unique:users',
            'address' => 'required',
            'profile_image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
            'designation' => 'required',
            'join_date' => 'required|date',
            'date_of_birth' => 'required|date',
            'experience' => 'required|integer|min:0',
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        
        // $profileImage = $request->file('profile_image');
        // $profileImageName = time() . '.' . $profileImage->extension();
        // $profileImagePath = $profileImage->storeAs('profile_images', $profileImageName, 'public');
        $profileImagePath = "test";
        // $user = User::create([
        //     'name' => $request->name,
        //     'email' => $request->email,
        //     'contact' => $request->contact,
        //     'address' => $request->address,
        //     'profile_image' => $profileImagePath,
        //     'designation' => $request->designation,
        //     'join_date' => $request->join_date,
        //     'date_of_birth' => $request->date_of_birth,
        //     'experience' => $request->experience,
        //     'password' => Hash::make($request->password),
        //     'type' => 'employee'
        // ]);
        $user = new User();

$user->fill([
    'name' => $request->name,
    'email' => $request->email,
    'contact' => $request->contact,
    'address' => $request->address,
    'profile_image' => $profileImagePath,
    'designation' => $request->designation,
    'join_date' => $request->join_date,
    'date_of_birth' => $request->date_of_birth,
    'experience' => $request->experience,
    'password' => Hash::make($request->password),
    'type' => 'employee'
]);

$user->save();

        
        Auth::login($user);

        return redirect()->route('login');
    }

    public function login()
    {
        return view('auth/login');
    }

    public function loginAction(Request $request)
    {
        Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required'
        ])->validate();

        if (!Auth::attempt($request->only('email', 'password'), $request->boolean('remember'))) {
            throw ValidationException::withMessages([
                'email' => trans('auth.failed')
            ]);
        }

        $request->session()->regenerate();

        
        if (auth()->user()->type == 'admin') {
            return redirect()->route('admin.home');
        } else {
            return redirect()->route('home');
        }
    }
    public function logout(Request $request)
    {
        Auth::guard('web')->logout();
 
        $request->session()->invalidate();
 
        return redirect('/login');
    }
 
    public function profile()
    {
        return view('userprofile');
    }
}