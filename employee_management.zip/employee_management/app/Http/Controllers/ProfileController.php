<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function edit()
    {
        return view('profile.edit');
    }

    public function update(Request $request)
    {
        
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . Auth::user()->id,
            'contact' => 'required|numeric|digits:10',
            'address' => 'required|string',
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'designation' => 'required|string|max:255',
            'join_date' => 'required|date',
            'date_of_birth' => 'required|date',
            'experience' => 'required|numeric|min:0',
        ]);

        
        $user = Auth::user();

        
        $user->name = $validatedData['name'];
        $user->email = $validatedData['email'];
        $user->contact = $validatedData['contact'];
        $user->address = $validatedData['address'];

        if ($request->hasFile('profile_image')) {
            
            if ($user->profile_image) {
                unlink(public_path($user->profile_image));
            }

            
            $image = $request->file('profile_image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads'), $imageName);
            $user->profile_image = 'uploads/' . $imageName;
        }

        $user->designation = $validatedData['designation'];
        $user->join_date = $validatedData['join_date'];
        $user->date_of_birth = $validatedData['date_of_birth'];
        $user->experience = $validatedData['experience'];

        $user->save();

        return redirect()->route('profile.edit')->with('success', 'Profile updated successfully!');
    }
    public function deleteImage(Request $request)
{
    $user = Auth::user();

    if ($user->profile_image) {
        unlink(public_path($user->profile_image));

        $user->profile_image = null;
        $user->save();

        return response()->json(['message' => 'Profile image deleted successfully']);
    }

    return response()->json(['message' => 'User does not have a profile image'], 404);
}
}
